'use client'

import ProfileEditForm from '@/components/profile/ProfileEditForm'

export default function ProfileEdit() {
  return (
    <div className="space-y-6">
      <ProfileEditForm />
    </div>
  );
}
