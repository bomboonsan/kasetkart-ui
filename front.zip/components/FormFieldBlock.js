export default function FormFieldBlock({ children }) {
  return <div className="py-5 my-1 border-b border-b-gray-100 space-y-10">{children}</div>;
}
